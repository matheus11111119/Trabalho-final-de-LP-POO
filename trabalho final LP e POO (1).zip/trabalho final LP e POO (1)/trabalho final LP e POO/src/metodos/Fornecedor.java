package metodos;
public class Fornecedor {
    private String nome;
    private int cpf;
    private String endereco;
    private double qntd;
    private double preco;
    public double getPreco() {
        return preco;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }
    public double getQntd() {
        return qntd;
    }
    public void setQntd(double qntd) {
        this.qntd = qntd;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public int getCpf() {
        return cpf;
    }
    public void setCpf(int cpf) {
        this.cpf = cpf;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
}
