package metodos;

public class Estoque {
    private int id;
    private double qntd;
    private String nome;
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public double getQntd() {
        return qntd;
    }
    public void setQntd(double qntd) {
        this.qntd = qntd;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
}
