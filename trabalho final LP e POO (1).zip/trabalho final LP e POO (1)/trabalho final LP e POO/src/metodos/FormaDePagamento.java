package metodos;

public class FormaDePagamento {
    private String debito;
    private String credito;
    private String boleto;
    private String pix;
    public String getDebito() {
        return debito;
    }
    public void setDebito(String debito) {
        this.debito = debito;
    }
    public String getCredito() {
        return credito;
    }
    public void setCredito(String credito) {
        this.credito = credito;
    }
    public String getBoleto() {
        return boleto;
    }
    public void setBoleto(String boleto) {
        this.boleto = boleto;
    }
    public String getPix() {
        return pix;
    }
    public void setPix(String pix) {
        this.pix = pix;
    }
}
