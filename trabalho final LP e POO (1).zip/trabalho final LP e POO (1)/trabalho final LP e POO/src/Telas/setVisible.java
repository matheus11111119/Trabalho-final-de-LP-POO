package Telas;

record setVisible(boolean b) {
    }
